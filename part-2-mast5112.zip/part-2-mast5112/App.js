import React, {useState} from 'react';
import SplashScreen from './Splashscreen.js';
import MenuListScreen from './Menulistscreen.js';
import AddItemScreen from './Additemscreen.js';
import DishDetailScreen from './Dishdetailscreen.js';

export default function App() {
  //Shows which screen is currently showng 'splash' , 'list' , 'add', 'details'
  const[screen, setScreen] = useState('splash');

  // The menu data stays here, at the top so hat ever sceen can read it.
  const [menuItems, setMenuItems] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);

  const handleSaveNewItem = (newItem) => {
    setMenuItems((prev) => [...prev, newItem]);
    setScreen('list');
  };
  const handleSelectItem = (item) => {
    setSelectedItem(item);
    setScreen('details');
  };

  if (screen === 'splash') {
    return <SplashScreen onFinish={() => setScreen('list')}/>
  }

  if (screen === 'add') {
    return (
      <AddItemScreen
      onCancel={() => setScreen('list')}
      onSave={handleSaveNewItem}
      />
    );
  }

  if (screen === 'details' && selectedItem) {
    return (
      <DishDetailScreen item={selectedItem} onBack={() => setScreen('list')} />
    );
  }

// For default screen.
  return (
    <MenuListScreen
    menuItems={menuItems}
    onAddNewItem={() => setScreen('add')}
    onSelectItem={handleSelectItem}
    />
  );
}