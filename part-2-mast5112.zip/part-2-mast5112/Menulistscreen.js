import React, {useState} from 'react';
import {SafeAreaView, View, Text, TextInput,TouchableOpacity, FlatList, StyleSheet, StatusBar,} from 'react-native';
import {COLOURS} from './Colours.js'

//menuItems show the array of dishes already added.
//When onAddNewItem is called when "+Add New Item" is pressed.
//When onSelectItem is called with the tapped item when a dish is tpped.
export default function MenuListScreen({menuItems, onAddNewItem, onSelectItem})
{
  //This field is visual only.
  const [searchText, setSearchText] = useState('');
  
  return (
    <SafeAreaView style={styles.screenLight}>
    <StatusBar barStyle="light-content" />
    <View style={styles.listHeader}>
    <Text style={styles.listHeaderTitle}>Menu Manager</Text>
    </View>

    <View style={styles.listBody}>
    <View style={styles.searchBar}>
    <Text style={styles.searchIcon}>🔍</Text>
    <TextInput
    style={styles.searchInput}
    placeholder="Search Item"
    placeholderTextColor={COLOURS.greyText}
    value={searchText}
    onChangeText={setSearchText}
    />
    </View>

    {menuItems.length === 0 ? (
      <View style={styles.emptyState}>
      <Text style={styles.emptyStateText}> No dishes have been added yet. Tap "+ Add New Item" below to get started. </Text>
         </View>
    ) : (
      <FlatList
      data={menuItems}
      keyExtractor={(item) => item.id}
      contentContainerStyle={{paddingBottom: 12}}
      renderItem={({item}) => (
        <TouchableOpacity
        style={styles.menuCard}
        onPress={() => onSelectItem(item)}
        >
        <View>
        <Text style={styles.menuCardName}>{item.dishName}</Text>
        <Text style={styles.menuCardCourse}>{item.course}</Text>
        </View>
        <Text style={styles.menuCardChevron}>›</Text>
        </TouchableOpacity>
      )}
      />
    )}
    </View>

    <View style={styles.addButtonWrap}>
    <TouchableOpacity style={styles.addButton} onPress={onAddNewItem}>
    <Text style={styles.addButtonText}>+ Add New Item</Text>
    </TouchableOpacity>
    </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screenLight: {
    flex: 1,
    backgroundColor: '#F4F5FA',
  },
  listHeader: {
    backgroundColor: COLOURS.navy,
    paddingTop: 30,
    paddingBottom: 16,
    alignItems: 'center',
  },
  listHeaderTitle: {
    color: COLOURS.white,
    fontSize: 20,
    fontWeight: 'bold',
  },
  listBody: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 14,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLOURS.lavender,
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 14,
  },
  searchIcon: {
    fontSize: 13,
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: COLOURS.navy,
  },
  menuCard: {
    backgroundColor: COLOURS.cardDark,
    borderRadius: 10,
    paddingVertical: 14,
    paddingHorizontal: 16,
    marginBottom: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  menuCardName: {
    color:  COLOURS.white,
    fontSize: 15,
    fontWeight: 'bold',
  },
  menuCardCourse: {
    color: '#9AA3B5',
    fontSize: 12,
    marginTop: 3,
  },
  menuCardChevron: {
    color: COLOURS.white,
    fontSize: 30,
  },
  emptyState: {
    backgroundColor: COLOURS.white,
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#E2E5EC',
    borderStyle: 'dashed',
  },
  emptyStateText: {
    color: COLOURS.greyText,
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 19,
  },
  addButtonWrap: {
    alignItems: 'center',
    paddingVertical: 50,
  },
  addButton: {
    backgroundColor: COLOURS.blue,
    borderRadius: 24,
    paddingVertical: 18,
    paddingHorizontal: 36,
  },
  addButtonText: {
    color: COLOURS.white,
    fontSize: 17,
    fontWeight: 'bold',
  },
   });