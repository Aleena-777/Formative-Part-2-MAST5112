import React from 'react';
import {View, StyleSheet} from 'react-native';
import {COLOURS} from './Colours.js';

export default function ChefHatIcon() {
  return (
    <View style={styles.hatWrap}>
    <View style={[styles.hatPuff, {left: 6, top:10}]} />
    <View style={[styles.hatPuff, {left: 24, top: 0}]} />
    <View style={[styles.hatPuff, {left: 42, top: 10}]} />
    <View style={styles.hatBody} />
    <View style={styles.hatBand} />
    </View>
  );
}

const styles = StyleSheet.create({
  hatWrap: {
    width: 70,
    height: 70,
    marginBottom: 18,
  },
  hatPuff: {
    position: 'absolute',
    width: 26,
    height: 26,
    borderRadius: 13,
    backgroundColor: COLOURS.white,
  },
  hatBody: {
    position: 'absolute',
    top: 18,
    left: 8,
    width: 54,
    height: 30,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    backgroundColor: COLOURS.white,
  },
  hatBand: {
    position: 'absolute',
    top: 46,
    left: 4,
    width: 62,
    height: 12,
    borderRadius: 4,
    backgroundColor: COLOURS.white,
  },
});