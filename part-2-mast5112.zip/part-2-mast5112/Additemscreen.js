import React, {useState} from 'react';
import {SafeAreaView, View, Text, TextInput, TouchableOpacity, StyleSheet, Modal, StatusBar, Alert} from 'react-native';
import {COLOURS, COURSES} from './Colours.js';

// When onCancel is called upon when the back arrow is pressed.
// When onSave is called upon with the new dish once validation passes.
export default function AddItemScreen({onCancel, onSave}) {
  const [dishName, setDishName] = useState('');
  const[course, setCourse] = useState('');
  const[price, setPrice] = useState('');
  const [description, setDescription] = useState ('');
  const [errors, setErrors] = useState({});
  const [courseModalVisible, setCourseModalVisible] = useState(false);

  const validate =() => {
    const newErrors = {};
    if (!dishName.trim()) newErrors.dishName = 'Dish name is required.';
    if (!course) newErrors.course = 'Please select a course.';
    if (!price.trim()) {
      newErrors.price = 'Price is required.';
    }else if (isNaN(Number(price)) || Number(price) <= 0 ) {
      newErrors.price = 'Enter a valid price greater than 0.';
    }
    if (!description.trim()) newErrors.description = 'Description is required.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
    };

    const handleSave = () => {
      if (!validate()) return;

      const newItem = {
        id: Date.now().toString(),
        dishName: dishName.trim(),
        course,
        price: Number(price).toFixed(2),
        description: description.trim(),
      };

      Alert.alert('Item Added', `"${newItem.dishName}" was added to the menu.`, [
        {text: 'OK', onPress: () =>onSave(newItem)},
      ]);
    };

    return (
      <SafeAreaView style={styles.screenWhite}>
      <StatusBar barStyle="light-content" />
      <View style={styles.headerRow}>
      <TouchableOpacity onPress={onCancel} style={styles.backBtn}>
      <Text style={styles.backArrow}>‹</Text>
      </TouchableOpacity>
      <Text style={styles.headerRowTitle}>Add Menu Item</Text>
      <View style={styles.backBtn} />
      </View>

      <View style={styles.formBody}>
      <Text style={styles.label}>Dish Name</Text>
      <TextInput
      style={[styles.input, errors.dishName && styles.inputError]}
      placeholder="e.g. Iced Tea"
      placeholderTextColor={COLOURS.grey}
      value={dishName}
      onChangeText={setDishName}
      />
      {errors.dishName ? <Text style={styles.errorText}>{errors.dishName}</Text> : null}

      <Text style={styles.label}>Course</Text>
      <TouchableOpacity
      style={[styles.input, styles.dropdown, errors.course && styles.inputError]}
      onPress={() => setCourseModalVisible(true)}
      >
      <Text style={course ? styles.dropdownValue : styles.dropdownPlaceholder}>
      {course || 'Select course'}
      </Text>
      <Text style={styles.dropdownChevron}>⌄</Text>
      </TouchableOpacity>
      {errors.course ? <Text style={styles.errorText}>{errors.course}</Text> : null}

     <Text style={styles.label}>Price</Text>
     <TextInput
     style={[styles.input, errors.price && styles.inputError]}
     placeholder="e.g. 20"
     placeholderTextColor={COLOURS.grey}
     value={price}
     onChangeText={setPrice}
     keyboardType="numeric"
     />
     {errors.price ? <Text style={styles.errorText}>{errors.price}</Text> : null}

     <Text style={styles.label}>Description</Text>
     <TextInput
     style={[styles.input, styles.textArea, errors.description && styles.inputError]}
     placeholder="Short description of item"
     placeholderTextColor={COLOURS.grey}
     value={description}
     onChangeText={setDescription}
     multiline
     numberOfLines={3}
     />
     {errors.description ? (
       <Text style={styles.errorText}>{errors.description}</Text> ) : null}

       <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
       <Text style={styles.saveButtonText}>Save Menu Item</Text>
       </TouchableOpacity>
       </View> 

       <Modal visible={courseModalVisible} transparent animationType="fade">
       <TouchableOpacity
       style={styles.modalOverlay}
       activeOpacity={1}
       onPress={() => setCourseModalVisible(false)}
       >
       <View style= {styles.modalCard}>
       <Text style={styles.modalTitle}>Select Course</Text>
       {COURSES.map((c) => (
         <TouchableOpacity
         key={c}
         style={styles.modalOption}
         onPress={() => {
           setCourse(c);
           setCourseModalVisible(false);
         }}
         >
         <Text style={styles.modalOptionText}>{c}</Text>
         </TouchableOpacity>
       ))}
       </View>
       </TouchableOpacity>
       </Modal>
       </SafeAreaView>
    );
  }

  const styles = StyleSheet.create({
    screenWhite: {
      flex: 1,
      backgroundColor: COLOURS.white,
    },
    headerRow: {
      backgroundColor: COLOURS.navy,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingTop: 30,
      paddingBottom: 16,
      paddingHorizontal: 8,
    },
    backBtn: {
      width: 36,
      alignItems: 'center',
    },
    backArrow: {
      color: COLOURS.white,
      fontSize: 30,
      fontWeight: 'bold',
    },
    headerRowTitle: {
      color: COLOURS.white,
      fontSize: 18,
      fontWeight: 'bold',
    },
    formBody: {
      padding: 20,
    },
    label: {
      fontSize: 13,
      fontWeight: '600',
      color: '#2c3e50',
      marginTop: 14,
      marginBottom: 6,
    },
    input: {
      backgroundColor: COLOURS.lavender,
      borderRadius: 8,
      paddingHorizontal: 14,
      paddingVertical: 12,
      fontSize: 14,
      color: COLOURS.navy,
    },
    textArea: {
      minHeight: 70,
      textAlignVertical: 'top',
    },
    inputError: {
      borderWidth: 1,
      borderColor: COLOURS.error,
    },
    errorText: {
      color: COLOURS.error,
      fontSize: 12,
      marginTop: 4,
    },
    dropdown: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
    },
    dropdownPlaceholder: {
      color: COLOURS.greyText,
      fontSize: 14,
    },
    dropdownValue: {
      color: COLOURS.navy,
      fontSize: 14,
      fontWeight: '600',
    },
    dropdownChevron: {
      color: COLOURS.greyText,
      fontSize: 16,
    },
    saveButton: {
      backgroundColor: COLOURS.navy,
      borderRadius: 24,
      paddingVertical: 14,
      alignItems: 'center',
      marginTop: 26,
    },
    saveButtonText: {
      color: COLOURS.white,
      fontSize: 15,
      fontWeight: 'bold',
    },
    modalOverlay: {
      flex: 1,
      backgroundColor: 'rgba(0,0,0,0.4)',
      justifyContent: 'center',
      alignItems: 'center',
    },
    modalCard: {
      backgroundColor: COLOURS.white,
      borderRadius: 12,
      padding: 18,
      width: '78%',
    },
    modalTitle: {
      fontSize: 14,
      fontWeight: 'bold',
      color: COLOURS.navy,
      marginBottom: 10,
    },
    modalOption: {
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: '#EEE',
    },
    modalOptionText: {
      fontSize: 14,
      color: '#2c3e50'
    },
  });