import React from 'react';
import {SafeAreaView, View, Text, TouchableOpacity, StyleSheet, StatusBar, Alert,} from 'react-native';
import {COLOURS} from './Colours.js'

//onBack is called upon when the back arrow is tapped.
//item is the selected dish.
export default function DishDetailScreen({item, onBack}) {
  return(
    <SafeAreaView style={styles.screenWhite}>
    <StatusBar barStyle="light-content"/>
    <View style={styles.headerRow}>
    <TouchableOpacity onPress={onBack} style={styles.backBtn}>
    <Text style={styles.backArrow}>‹</Text>
    </TouchableOpacity>
    <Text style={styles.headerRowTitle}>Dish Detail</Text>
    <View style={styles.backBtn}/>
    </View>

    <View style={styles.detailBody}>
    <Text style={styles.detailName}>{item.dishName}</Text>
    <Text style={styles.detailBullet}>• Course: {item.course}</Text>
    <Text style={styles.detailBullet}>• Price: R{item.price}</Text>

    <Text style={styles.detailLabel}>Description:</Text>
    <Text style={styles.detailDescription}>{item.description}</Text>

    <View style={{height: 300}}/>

    <TouchableOpacity
    style={styles.editButton}
    onPress={() =>
    Alert.alert('Coming Soon', 'Editing items will be available in the future.')
    }
    >
    <Text style={styles.editButtonText}>Edit Item</Text>
    </TouchableOpacity>
    <TouchableOpacity
    style={styles.deleteButton}
    onPress={() =>
    Alert.alert('Coming Soon', 'Deleting items will be available in the future.')
    }
    >
    <Text style={styles.deleteButtonText}>Delete Item</Text>
    </TouchableOpacity>
    </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screenWhite: {
    flex: 1,
    backgroundColor: COLOURS.white,
  },
  headerRow: {
    backgroundColor: COLOURS.navy,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 30,
    paddingBottom: 16,
    paddingHorizontal: 8,
  },
  backBtn: {
    width: 36,
    alignItems: 'center',
  },
  backArrow: {
    color: COLOURS.white,
    fontSize: 30,
    fontWeight: 'bold',
  },
  headerRowTitle: {
    color: COLOURS.white,
    fontSize: 18,
    fontWeight: 'bold',
  },
  detailBody: {
    flex: 1,
    padding: 20,
  },
  detailName: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#111111',
    marginBottom: 8,
  },
  detailBullet: {
    fontSize: 14,
    color: '#333333',
    marginBottom: 4,
  },
  detailLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#111111',
    marginTop: 18,
    marginBottom: 6,
  },
  detailDescription: {
    fontSize: 14,
    color: '#444444',
    lineHeight: 20,
  },
  editButton: {
    backgroundColor: COLOURS.blue,
    borderRadius: 24,
    paddingVertical: 14,
    alignItems: 'center',
    marginBottom: 12,
  },
  editButtonText: {
    color: COLOURS.white,
    fontSize: 15,
    fontWeight: 'bold',
  },
  deleteButton: {
    backgroundColor: COLOURS.black,
    borderRadius: 24,
    paddingVertical: 14,
    alignItems: 'center',
  },
  deleteButtonText: {
    color: COLOURS.white,
    fontSize: 15,
    fontWeight: 'bold',
  },
});