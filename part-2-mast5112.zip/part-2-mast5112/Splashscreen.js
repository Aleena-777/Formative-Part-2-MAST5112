import React, {useEffect} from 'react';
import {SafeAreaView, Text, StyleSheet, StatusBar} from 'react-native';
import {COLOURS} from './Colours.js'
import ChefHatIcon from './Chefhaticon.js';

//Shows the splash for a short delay, then calls onFinish() to move the list screen.
export default function SplashScreen({onFinish}) {
  useEffect(() => {
    const timer = setTimeout(onFinish, 1500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
    <StatusBar barStyle="light-content"/>
    <ChefHatIcon />
    <Text style={styles.title}>Menu Manager</Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLOURS.navy,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    color: COLOURS.white,
    fontSize: 20,
    fontWeight: 'bold',
    letterSpacing: 0.5,
  },
});